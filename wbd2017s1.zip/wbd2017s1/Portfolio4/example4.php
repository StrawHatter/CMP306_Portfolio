<html>
<head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="MyStyle.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>
<body>

<?php

	$xmlDoc = new DOMDocument();
   	$xmlDoc->load("contact.xml");

   $xslDoc = new DOMDocument();
   $xslDoc->load("example2.xsl"); 

   $proc = new XSLTProcessor();
   $proc->importStylesheet($xslDoc);
   $xname = $_GET["id"] ;
   $proc->setParameter('', 'xname', $xname );
   echo $proc->transformToXML($xmlDoc);

?>

</body>
</html>