<html>
<head></head>
<body>

<?php

	$xmlDoc = new DOMDocument();
   	$xmlDoc->load("contact.xml");

   $xslDoc = new DOMDocument();
   $xslDoc->load("getnumbers.xsl"); 

   $proc = new XSLTProcessor();
   $proc->importStylesheet($xslDoc);
   $proc->setParameter('', '*', '');
   echo $proc->transformToXML($xmlDoc);

?>

</body>
</html>