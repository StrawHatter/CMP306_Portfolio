<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="MyStyle.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
    
<body>
    <div class="container">
    <h1>CMP306 - Web Development 2 Portfolio 4</h1>
    <p>Paul Dreczkowski - 1301428</p>        
</div>

    <?php

	$xmlDoc = new DOMDocument();
   	$xmlDoc->load("contact.xml");

   $xslDoc = new DOMDocument();
   $xslDoc->load("getnumbers.php"); 

   $proc = new XSLTProcessor();
   $proc->importStylesheet($xslDoc);
   echo $proc->transformToXML($xmlDoc);

?>

</body>
</html>
