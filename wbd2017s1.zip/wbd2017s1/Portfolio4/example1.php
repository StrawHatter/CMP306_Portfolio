<html>
<head></head>
<body>

<?php

	$xmlDoc = new DOMDocument();
   	$xmlDoc->load("contact.xml");

   $xslDoc = new DOMDocument();
   $xslDoc->load("example1.xsl"); 

   $proc = new XSLTProcessor();
   $proc->importStylesheet($xslDoc);
   echo $proc->transformToXML($xmlDoc);

?>

</body>
</html>