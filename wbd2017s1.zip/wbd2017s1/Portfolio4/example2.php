<html>
<head></head>
<body>

<?php

	$xmlDoc = new DOMDocument();
   	$xmlDoc->load("contact.xml");

   $xslDoc = new DOMDocument();
   $xslDoc->load("example2.xsl"); 

   $proc = new XSLTProcessor();
   $proc->importStylesheet($xslDoc);
   $proc->setParameter('', 'xname', 'Alice');
   echo $proc->transformToXML($xmlDoc);

?>

</body>
</html>