<?php

session_start();
session_destroy();
?>

<html>
<head>
    </head>
    <body>
    <meta http-equiv="refresh" content="1;url=login.php"/>
    </body>
</html>