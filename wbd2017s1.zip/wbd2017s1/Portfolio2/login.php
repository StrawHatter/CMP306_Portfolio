<?php
    session_start();

    if(isset($_POST['login'])){
        include_once("db.php");
        
        //Prevent against SQL Injection
        $username = strip_tags($_POST['username']);
        $password = strip_tags($_POST['password']);
            
        //Remove slashes from our input variable from the form
        $username = stripslashes($username);
        $password = stripslashes($password);
        
        //Removes special characters from our variables
        $username = mysqli_real_escape_string($db, $username);
        $password = mysqli_real_escape_string($db, $password);
        
        //MD5 Encrypt password input variable 
        $password = md5($password);
        
        //Get information from database to check whether the username matches the correct password
        $sql = "SELECT * FROM users WHERE username = '$username' LIMIT 1";
        $query = mysqli_query($db, $sql);
        $row = mysqli_fetch_array($query);
        
        $id = $row['id'];
        $db_password = $row['password'];
        
         echo $db_password;
        
        if($password == $db_password){
            $_SESSION['username'] = $username; 
            $_SESSION['id'] = $id;
            header("Location: index.php");
        }
        else {
            echo "Wrong Username or Password!";
        }
        
        
    }
?>

<html>
<head>
    <title>Login</title>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="MyStyle.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <h1 style="font-family: Tahoma;">Login</h1>
        <form action="login.php" method="post" enctype="multipart/form-data">
            <input placeholder="Username" name="username" type ="text" autofocus> 
            <input placeholder="Password" name="password" type ="password">
            <input name="login" type="submit" value="Login">
        </form>
        <a href="register.php">Register if you are a new user</a>
    </body>
</html>