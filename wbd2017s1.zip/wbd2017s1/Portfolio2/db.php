<?php
$db = mysqli_connect("lochnagar.abertay.ac.uk", "sql1301428", "a08nuZVnSe", "sql1301428");