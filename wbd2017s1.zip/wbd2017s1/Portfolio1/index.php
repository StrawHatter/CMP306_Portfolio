<?php
              
        $servername1 = 'lochnagar.abertay.ac.uk';
        $username1 = 'sql1301428';
        $password1 = 'a08nuZVnSe';
        $dbname1 = 'sql1301428';
        $connection1 = mysql_connect($servername1, $username1, $password1, $dbname1);
        if (!$connection1){
            echo "Error";
        }
        mysql_select_db($dbname1);
?>
<html>
<head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="MyStyle.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
</head>
<body>
    
	<h1>Display All Films</h1>
    <div class="container">
	<?php
              
		$sql = "SELECT * FROM movies" ;
		$result = mysql_query($sql);
              
		while($rows = mysql_fetch_array($result)) {
			echo "<a href='http://mayar.abertay.ac.uk/~1301428/wbd2017s1/Portfolio1/displaycontact2.php?id=".$rows[0]."'><img class='resize' src='".$rows[4]."'width='500' height='700'></img></a>";
            echo "<p></p>";
		}
	?> 
    </div>
</body>
</html>