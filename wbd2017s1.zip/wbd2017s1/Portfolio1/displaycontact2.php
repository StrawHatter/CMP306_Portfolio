<?php
include("library2.php");
?>
<html>
<head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="MyStyle.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
</head>
<body>
	<h1>Display Film</h1>
	   <div class="container">
		  <div class="row">
            <?php
              $id = $_GET['id'];
              $filmtext = getFilmsById($id);
              $filmjson = json_decode($filmtext);
              echo $filmjson;
            ?>
        </div>
     </div>
</body>
</html>