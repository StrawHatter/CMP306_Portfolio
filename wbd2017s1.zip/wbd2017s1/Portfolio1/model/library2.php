<?php
function getFilmsByID($id){

        $servername1 = 'lochnagar.abertay.ac.uk';
        $username1 = 'sql1301428';
        $password1 = 'a08nuZVnSe';
        $dbname1 = 'sql1301428';
        $connection1 = mysql_connect($servername1, $username1, $password1, $dbname1);
        if (!$connection1){
            echo "Error";
        }
        mysql_select_db($dbname1);
    
        $sql = "SELECT * FROM movies WHERE id = ".$id ;
        $result = mysql_query($sql);
        while($rows = mysql_fetch_array($result)) {
			$filmtext = $rows[1]."<img src='".$rows[4]."'></p><p>".$rows[4]."</p><p>Language: ".$rows[3].".</p><p><b>Description:</b> ".$rows[3]."</p>";
			
        }


    return json_encode($filmtext);

}
?>