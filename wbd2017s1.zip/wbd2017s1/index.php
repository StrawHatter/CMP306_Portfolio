<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="MyStyle.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
    
<body>
    <div class="container">
    <h1>CMP306 - Web Development 2 Portfolio</h1>
    <p>Paul Dreczkowski - 1301428</p>        
</div>

    <p><a href="Portfolio1/index.php">Portfolio 1</a></p>
    <p><a href="Portfolio2/index.php">Portfolio 2</a></p>
    <p><a href="Portfolio3/index.php">Portfolio 3</a></p>
    <p><a href="Portfolio4/index.php">Portfolio 4</a></p>
    <p><a href="report.html">Report</a></p>

    
</body>
</html>
