<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="MyStyle.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="//code.jquery.com/mobile/1.5.0-alpha.1/jquery.mobile-1.5.0-alpha.1.min.css">
  <script src="//code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="//code.jquery.com/mobile/1.5.0-alpha.1/jquery.mobile-1.5.0-alpha.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
    
<body>

    

    <?php
    $servername = 'lochnagar.abertay.ac.uk';
        $username = 'sql1301428';
        $password = 'a08nuZVnSe';
        $dbname = 'sql1301428';
        $connection = mysql_connect($servername, $username, $password, $dbname);
        if (!$connection){
            echo "Error";
        }
        mysql_select_db($dbname);
    
    $sql = "SELECT * FROM analogueinputs ORDER BY id ASC";
    $results = mysql_query($sql, $connection);
        
            echo "<div class='container'>";
    echo "<h1>CMP306 - Web Development 2 Portfolio 3</h1>";
    echo "<p>Paul Dreczkowski - 1301428</p>";    
echo "</div>";
    
    echo "<div data-role='page' id='page1'>";
    echo "<div role='main' class='ui-content'>";
    echo "<table data-role='table' id='inputs_table' data-mode='reflow' class='ui-responsive table-stroke'>";
    echo "<thead>";
        echo "<tr>";
            echo "<th data-priority='1'>ID</th>";
            echo "<th data-priority=persist'>Internal Temperature</th>";
            echo "<th data-priority='2'>External Temperature</th>";
            echo "<th data-priority='3'>Luminosity</th>";
            echo "<th data-priority='4'>Device</th>";
            echo "<th data-priority='5'>Date of Analogue Input Capture</th>";
        echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    
    while($row = mysql_fetch_array($results))
      {
        echo "<tr>";
        echo "<td>".$row[0]."</td>";
        echo "<td>".$row[1]."</td>";
        echo "<td>".$row[2]."</td>";
        echo "<td>".$row[3]."</td>";
        echo "<td>".$row[4]."</td>";
        echo "<td>".$row[5]."</td>";
        echo "</tr>";
      }
    
    echo "</tbody>";
    echo "</table>";
    echo "</div>";
    echo "</div>";
?>

</body>
</html>
