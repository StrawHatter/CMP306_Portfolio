<html>
<head>
    
</head>
    <body>
        
    <?php
        $servername = 'lochnagar.abertay.ac.uk';
        $username = 'sql1301428';
        $password = 'a08nuZVnSe';
        $dbname = 'sql1301428';
        $connection = mysql_connect($servername, $username, $password, $dbname);
        if (!$connection){
            echo "Error";
        }
        mysql_select_db($dbname);
        $tempfile = file_get_contents("php://input") ;
        $jsondecode = json_decode($tempfile) ;
        $i = 0;
        foreach($jsondecode as $key => $value){
            
            //loop name and contents to fill these arrays up with individual data
            $outputs[$i] = $value;
            $i++;
        }
        $sql = "INSERT into analogueinputs(device, internaltemp, externaltemp, luminosity) VALUES('$outputs[1]', '$outputs[0]', '$outputs[3]', '$outputs[2]')";
        mysql_query($sql, $connection);
        
        
        ?>
    </body>
</html>